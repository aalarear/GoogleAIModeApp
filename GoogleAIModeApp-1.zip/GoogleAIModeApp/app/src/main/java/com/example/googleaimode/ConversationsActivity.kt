package com.example.googleaimode

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ConversationsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyText: View
    private lateinit var adapter: ConversationAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversations)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        recyclerView = findViewById(R.id.recyclerView)
        emptyText = findViewById(R.id.emptyText)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = ConversationAdapter(
            items = PrefsHelper.getAll(this),
            onOpen = { conv ->
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("OPEN_URL", conv.url)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
                finish()
            },
            onPinToggle = { conv ->
                PrefsHelper.togglePin(this, conv.id)
                refreshList()
            },
            onRename = { conv -> showRenameDialog(conv) },
            onDelete = { conv ->
                PrefsHelper.deleteConversation(this, conv.id)
                refreshList()
                Toast.makeText(this, "تم الحذف", Toast.LENGTH_SHORT).show()
            }
        )
        recyclerView.adapter = adapter
        refreshList()
    }

    private fun refreshList() {
        val list = PrefsHelper.getAll(this)
        adapter.updateData(list)
        emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showRenameDialog(conv: Conversation) {
        val input = EditText(this)
        input.setText(conv.title)
        input.setSelection(input.text.length)

        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(input)
            .setPositiveButton(R.string.btn_save) { _, _ ->
                val newTitle = input.text.toString().trim()
                if (newTitle.isNotEmpty()) {
                    PrefsHelper.renameConversation(this, conv.id, newTitle)
                    refreshList()
                }
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }
}
