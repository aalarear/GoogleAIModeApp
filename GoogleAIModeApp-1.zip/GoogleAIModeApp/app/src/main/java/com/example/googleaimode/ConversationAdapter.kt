package com.example.googleaimode

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ConversationAdapter(
    private var items: MutableList<Conversation>,
    private val onOpen: (Conversation) -> Unit,
    private val onPinToggle: (Conversation) -> Unit,
    private val onRename: (Conversation) -> Unit,
    private val onDelete: (Conversation) -> Unit
) : RecyclerView.Adapter<ConversationAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.titleText)
        val url: TextView = view.findViewById(R.id.urlText)
        val pinBadge: TextView = view.findViewById(R.id.pinBadge)
        val btnPin: android.widget.Button = view.findViewById(R.id.btnPin)
        val btnRename: android.widget.Button = view.findViewById(R.id.btnRename)
        val btnDelete: android.widget.Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_conversation, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.title.text = item.title
        holder.url.text = item.url
        holder.pinBadge.visibility = if (item.pinned) View.VISIBLE else View.GONE
        holder.btnPin.text = if (item.pinned)
            holder.itemView.context.getString(R.string.btn_unpin)
        else
            holder.itemView.context.getString(R.string.btn_pin)

        holder.itemView.setOnClickListener { onOpen(item) }
        holder.btnPin.setOnClickListener { onPinToggle(item) }
        holder.btnRename.setOnClickListener { onRename(item) }
        holder.btnDelete.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: MutableList<Conversation>) {
        items = newItems
        notifyDataSetChanged()
    }
}
