package com.example.googleaimode

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class AIModeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val night = PrefsHelper.isNightMode(this)
        AppCompatDelegate.setDefaultNightMode(
            if (night) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }
}
