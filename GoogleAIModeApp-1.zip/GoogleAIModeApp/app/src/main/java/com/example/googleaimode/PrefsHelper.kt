package com.example.googleaimode

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * كل البيانات هنا محفوظة محلياً على الجهاز فقط (SharedPreferences)
 * ولا علاقة لها بحساب جوجل أو خوادم جوجل إطلاقاً.
 */
object PrefsHelper {

    private const val PREFS_NAME = "ai_mode_prefs"
    private const val KEY_CONVERSATIONS = "conversations"
    private const val KEY_NIGHT_MODE = "night_mode"
    private const val KEY_LAST_URL = "last_url"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ---------- Conversations ----------

    fun getAll(context: Context): MutableList<Conversation> {
        val raw = prefs(context).getString(KEY_CONVERSATIONS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<Conversation>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Conversation(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    url = o.getString("url"),
                    pinned = o.optBoolean("pinned", false),
                    savedAt = o.optLong("savedAt", System.currentTimeMillis())
                )
            )
        }
        // المثبتة أولاً، ثم الأحدث
        list.sortWith(compareByDescending<Conversation> { it.pinned }.thenByDescending { it.savedAt })
        return list
    }

    private fun saveAll(context: Context, list: List<Conversation>) {
        val arr = JSONArray()
        for (c in list) {
            val o = JSONObject()
            o.put("id", c.id)
            o.put("title", c.title)
            o.put("url", c.url)
            o.put("pinned", c.pinned)
            o.put("savedAt", c.savedAt)
            arr.put(o)
        }
        prefs(context).edit().putString(KEY_CONVERSATIONS, arr.toString()).apply()
    }

    fun addConversation(context: Context, title: String, url: String): Conversation {
        val list = getAll(context)
        val newConv = Conversation(id = System.currentTimeMillis(), title = title, url = url)
        list.add(newConv)
        saveAll(context, list)
        return newConv
    }

    fun renameConversation(context: Context, id: Long, newTitle: String) {
        val list = getAll(context)
        list.find { it.id == id }?.title = newTitle
        saveAll(context, list)
    }

    fun togglePin(context: Context, id: Long) {
        val list = getAll(context)
        list.find { it.id == id }?.let { it.pinned = !it.pinned }
        saveAll(context, list)
    }

    fun deleteConversation(context: Context, id: Long) {
        val list = getAll(context)
        list.removeAll { it.id == id }
        saveAll(context, list)
    }

    // ---------- Theme ----------

    fun isNightMode(context: Context): Boolean =
        prefs(context).getBoolean(KEY_NIGHT_MODE, false)

    fun setNightMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_NIGHT_MODE, enabled).apply()
    }

    // ---------- Last session (to resume where you left off) ----------

    fun setLastUrl(context: Context, url: String) {
        prefs(context).edit().putString(KEY_LAST_URL, url).apply()
    }

    fun getLastUrl(context: Context): String? =
        prefs(context).getString(KEY_LAST_URL, null)
}
