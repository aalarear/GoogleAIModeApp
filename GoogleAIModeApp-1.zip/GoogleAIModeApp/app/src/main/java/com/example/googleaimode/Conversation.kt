package com.example.googleaimode

data class Conversation(
    val id: Long,
    var title: String,
    val url: String,
    var pinned: Boolean = false,
    val savedAt: Long = System.currentTimeMillis()
)
